document.getElementById("register-form").addEventListener("submit", async(event)=>{
    event.preventDefault()
    const username = document.getElementById('username').value
    const email = document.getElementById('email').value
    const password = document.getElementById('password').value
    try {
        const response = await fetch('/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, email, password }) 
        })
        
        if (response.ok) {
            Swal.fire({
                icon: 'success',
                title: 'Register successful',
                text: 'Registered in successfully!',
            }).then(() => {
                window.location.href = '/auth/login'; 
            });
        } else {
            const errorMessage = await response.text();
            Swal.fire({
                icon: 'error',
                title: 'Register Failed',
                text: errorMessage,
            });
        }
    } catch (error) {
        console.error('Error during registration:', error);
        Swal.fire({
            icon: 'error',
            title: 'An error occurred',
            text: 'Please try again later.',
        });
    }
})