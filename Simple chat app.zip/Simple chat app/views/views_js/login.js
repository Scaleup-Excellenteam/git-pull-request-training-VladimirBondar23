document.getElementById("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault(); 

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    try {
        const response = await fetch('/auth/login', {  
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }) 
        });

        if (response.ok) {
            Swal.fire({
                icon: 'success',
                title: 'Login successful',
                text: 'Logged in successfully!',
            }).then(() => {
                window.location.href = '/'; 
            });
        } else {
            const errorMessage = await response.text();
            Swal.fire({
                icon: 'error',
                title: 'Login Failed',
                text: errorMessage,
            });
        }
    } catch (error) {
        console.error('Error during login:', error);
        Swal.fire({
            icon: 'error',
            title: 'An error occurred',
            text: 'Please try again later.',
        });
    }
});

