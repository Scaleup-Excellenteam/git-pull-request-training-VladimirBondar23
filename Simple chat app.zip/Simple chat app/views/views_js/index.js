window.onload = async function() {
    try {
        const response = await fetch('/message/get-messages');
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        if (data.all_messages){
        data.all_messages.forEach(message => {
            let formattedDate = new Date(message.date).toLocaleString();
            let side = message.role == "model"? "left" : "right"
            addMessage(message.parts[0].text, side, formattedDate);
        });
    }
    } catch (error) {
        console.error("Error fetching messages:", error);
    }
};

document.getElementById('sendMessageButton').addEventListener('click', async function() {
    document.getElementById('hdr').innerHTML = '';
    const messageInput = document.getElementById('messageInput');
    const messageText = messageInput.value;
    if (messageText) {
        addMessage(messageText, "right", new Date().toLocaleString());
        await sendToAi(messageText)
        messageInput.value = '';
    }
});


document.getElementById('surprise').addEventListener('click', async () => {
    await sendToAi("surprise me with a random fact")})



document.getElementById('clear').addEventListener('click', async ()=>{
    try {
        const response = await fetch('message/get-messages', {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
        })
        if (response.ok){
            window.location.href = '/'
        }
        else{
            throw new Error("Something went wrong")
        }
    } catch (error) {
        console.log("Error clearing history", error)
    }
})


function addMessage(messageText, side, date) {
    const messageDiv = document.createElement('div')
    messageDiv.classList.add('message-bubble', `${side}`, 'message-text-style')
    messageDiv.style.textAlign = 'left'
    messageDiv.textContent = `${date}\n${messageText}`
    messageDiv.style.whiteSpace = 'pre-wrap'
    const messagesContainer = document.getElementById('messages')
    messagesContainer.appendChild(messageDiv)
    messagesContainer.scrollTop = messagesContainer.scrollHeight
}



async function sendToAi (message) {
    document.getElementById('hdr').innerHTML = ''
    const new_message = 
        {
            role: "user",
            parts: [{ text: message }]
        }
    try {
        const response = await fetch('/message/send-message', {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ new_message }) 
        })
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`)
        }
        const data = await response.json()
        const formattedDate = new Date(data.date).toLocaleString();
        addMessage(data.message, "left", formattedDate)
    } catch (error) {
        console.error("Error sending message:", error);
    }
};





