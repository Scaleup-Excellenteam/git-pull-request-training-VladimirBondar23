const User = require('../models/User')
const sessionHandler = (req, res, next) => {
    if (!req.session.username) {
        req.session.username = "Guest"
    }
    next()
}

const cookie_check = async (req, res, next) => {
    const sessionToken = req.cookies.session_token;

    if (!sessionToken) {
        req.user = null; 
        return next();
    }

    try {
        const user = await User.findById(sessionToken);
        if (!user) {
            res.clearCookie('session_token'); 
            return res.status(401).send('Session expired. Please log in again.');
        }
        req.user = user; 
        next();
    } catch (err) {
        res.clearCookie('session_token'); 
        return res.status(500).send('Error retrieving user');
    }
};



module.exports = {sessionHandler, cookie_check}