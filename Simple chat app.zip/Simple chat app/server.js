const express = require('express')
const session = require('express-session')
const mongoose = require('mongoose');
const dotenv = require('dotenv')
dotenv.config()
const cookieparser = require('cookie-parser')
const bodyparser = require('body-parser')
const path = require('path');
const {sessionHandler, cookie_check} = require('./middleware/middleware.js')
const authRouter = require('./routes/auth.js')
const messageRouter = require('./routes/message.js')
const PORT = 3000
const app = express()

app.set('view engine', 'ejs')
app.set('views', path.join(__dirname, 'views'))
app.use(cookieparser())
app.use(bodyparser.json())
app.use(bodyparser.urlencoded({extended: true}))
app.use('/views_js', express.static('views/views_js'));
app.use('/auth/views_js', express.static('views/views_js'));
app.use('/routes/controllers', express.static('routes/controllers'));
app.use('/images', express.static('images'));
app.use('/styles', express.static('styles'));
app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true
}))



app.use(sessionHandler)
app.use(cookie_check)
app.use('/auth', authRouter);
app.use('/message', messageRouter);

const mongo_url = process.env.MONGO_URL
mongoose.connect(mongo_url).then( () => {
    console.log('Connected to MongoDB');
})



app.get('/', async (req, res) => {
    let username = req.user? req.user.username : "Guest"
    let isGuest = req.user? false : true 
    res.render('index', { username: username, isGuest: isGuest});
});




app.listen(PORT, ()=>{
    console.log(`Server is running at http://localhost:${PORT}`);
})
