const User = require('../../models/User')
class Message{
    constructor(role, parts) {
        this.role = role
        this.parts = parts
    }
}

class MessageAPI extends Message{
    constructor(role, parts, date) {
        super(role,parts)
        this.date = date
    }

    static async ask_ai(content) {
        const apiKey = "AIzaSyAOCq_Vsd_nVml6kIRxqkMSz4NLOH4dtW8"; 
        const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`;
        const requestBody = {
            contents: content
        };        
        
        try {
            const response = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(requestBody)
            });
            const data = await response.json();
            
            const generatedText = data.candidates?.[0]?.content?.parts?.[0]?.text ;
            return generatedText
        } catch (error) {
            console.error("Error fetching Gemini API:", error);
        }
    }


    static async getAllMessages(sessionToken = null) { 
        if (sessionToken) {
            try {
                const user = await User.findById(sessionToken);
                
                return user?.messages.map(message => ({
                    role: message.role,
                    parts: message.parts.map(part => ({ text: part.text })), 
                    date: new Date(message.date)
                })) || []; 
            } catch (error) {
                console.error("Error fetching user messages:", error);
                return []; 
            }
        }
        return [];
    }
}

module.exports = {MessageAPI, Message}