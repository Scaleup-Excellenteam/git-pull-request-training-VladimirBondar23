const express = require('express');
const router = express.Router();
const {MessageAPI, Message} = require('../routes/controllers/message_controller');
const User = require('../models/User')




router.post('/send-message', async (req, res) => {
    const sessionToken = req.cookies?.session_token || null
    let contentsForDB = sessionToken? await MessageAPI.getAllMessages(sessionToken) : req.session.messages || [];
    let contentsForAI = contentsForDB.map(message => new Message(message.role, message.parts))

    try {
        const new_message = req.body.new_message
        const MessageObjectForDB = new MessageAPI(new_message.role, new_message.parts, new Date())
        const MessageForAI = new Message(new_message.role, new_message.parts)
        
        contentsForAI.push(MessageForAI)
        const answer = await MessageAPI.ask_ai(contentsForAI);
        if (!answer){
            res.status(500).json({ error: "Failed to generate response message." });
        }
        const messageFromAnswer = new MessageAPI("model",  [{ text: answer }] ,new Date())
        contentsForDB.push(MessageObjectForDB)
        contentsForDB.push(messageFromAnswer)

        if (sessionToken){
            const user = await User.findById(sessionToken);
            user.messages = contentsForDB; 
            await user.save();
        }
        else{
            req.session.messages = contentsForDB;
        }
        
        res.json({ message: answer, date: MessageObjectForDB.date}); 
    } catch (error) {
        console.error("Error related to AI:", error);
        res.status(500).json({ error: "Failed to generate response message." });
    }
});





router.get('/get-messages', async(req,res)=>{
    try {
        const sessionToken = req.cookies?.session_token || null
        let messages = []
        if (sessionToken){
            messages = await MessageAPI.getAllMessages(sessionToken)
        }
        else{
            messages = req.session.messages
        }
        res.json({all_messages: messages})
    } catch (error) {
        console.error("Error related to AI:", error);
        res.status(500).json({ error: "Failed to generate response message." });
    }
})



router.put('/get-messages', async (req,res)=>{
    try {
        let messages = []
        const sessionToken = req.cookies?.session_token || null
        if (sessionToken){
            const user = await User.findById(sessionToken);
            user.messages = []
            await user.save();
        }
        else{
            req.session.messages = [];
        }
        res.json({all_messages : messages})
    } catch (error) {
        console.error("Error related to database:", error);
        res.status(500).json({ error: "Failed to update database with []." });
    }
})







module.exports = router;
