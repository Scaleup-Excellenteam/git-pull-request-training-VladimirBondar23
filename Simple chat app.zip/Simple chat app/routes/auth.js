const express = require('express')
const router = express.Router()
const User = require('../models/User')





router.route('/login')
    .get((req, res) => {
        res.render('login');  
    })



    .post(async (req,res) => {
        const username = req.body.username
        const password = req.body.password
        try {
            const user = await User.findOne({ username: username });
            if (!user) {
                return res.status(400).send("Invalid username or password");
            }
            const isMatch = user.password === password
            if (!isMatch) {
                return res.status(400).send("Invalid username or password");
            }
            const sessionToken = user._id;

            res.cookie('session_token', sessionToken, {
                httpOnly: true, 
                secure: process.env.NODE_ENV === 'production', 
                maxAge: 24* 60 * 60 * 1000,
            });
            return res.status(200).send("logged in")
        } catch (error) {
            console.error("Login error:", error);
            res.status(500).send("Internal Server Error");
        }
    })







router.route('/register')
    .get( (req, res) => {
        res.render('register');  
    })



    .post(async (req,res) => {
        try {
            const {username, password, email} = req.body
            if (password.length < 3){
                return res.status(400).send("Password should be longer than 3 symbols")
            }
            const existing = await User.findOne ({email: email})
            if (existing){
                return res.status(400).send("User with this email exists")
            }
            const user = new User({username: username, password: password, email:email, messages:[]})
            await user.save()
            return res.status(200).send("Registered successfully")
        } catch (error) {
            console.error("Login error:", error);
            res.status(500).send("Internal Server Error");
        }
    })


router.route('/logout')
    .get(async (req,res)=>{
        res.clearCookie('session_token'); 
        req.session.destroy(err => { 
            if (err) {
                console.error("Error logging out:", err);
                return res.status(500).send("Failed to log out");
            }
        res.redirect('/'); 
});
    })




module.exports = router