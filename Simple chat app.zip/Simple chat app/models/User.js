const mongoose = require('mongoose')

const messageSchema = new mongoose.Schema({
    role: String,
    parts: [{ text: String }], 
    date: { type: Date }
});


const userSchema = new mongoose.Schema({
    username: String,
    password: String,
    email: String,
    messages: [messageSchema]
})

const User = mongoose.model("User", userSchema)
module.exports = User