USE [Bugs]
GO

/****** Object: Table [dbo].[Categories] Script Date: 13.02.2025 21:10:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Categories] (
    [Id]               INT           IDENTITY (1, 1) NOT NULL,
    [CategoryName]     NVARCHAR (20) NOT NULL,
    [ParentCategoryId] INT           NOT NULL
);


