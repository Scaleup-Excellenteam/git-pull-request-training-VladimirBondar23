USE [Bugs]
GO

/****** Object: Table [dbo].[Bugs] Script Date: 13.02.2025 21:09:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Bugs] (
    [Id]          INT           IDENTITY (1, 1) NOT NULL,
    [Title]       NVARCHAR (20) NOT NULL,
    [Description] VARCHAR (100) NULL,
    [Status]      VARCHAR (100) NULL,
    [CategoryId]  INT           NULL
);


