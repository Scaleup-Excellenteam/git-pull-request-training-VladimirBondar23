﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telhai.CS.DotNet.GadShor.Repositories
{

    enum RepositoryType
    {
        InMemoryMock = 0,
        JsonFile = 1,
        SQL = 2,
        Categories = 3
    }

    class StaticFactory
    {

        public static IBugsRepository GetBugsRepository(RepositoryType type)
        {
            return type switch
            {
                RepositoryType.InMemoryMock => new MockRepository(),
                RepositoryType.JsonFile => JsonRepository.Instance,
                RepositoryType.SQL => SqlRepository.Instance,
                
                _ => throw new NotImplementedException()
            };

            
        }
        public static IBugsRepository GetBugsRepository<T>() where T : IBugsRepository
        {
            if (typeof(T) == typeof(MockRepository))
            {
                return new MockRepository();
            }
            else if (typeof(T) == typeof(JsonRepository))
            {
                return JsonRepository.Instance;
            }
            else if (typeof(T) == typeof(SqlRepository))
            {
                return SqlRepository.Instance;
            }
            else
            {
                throw new NotImplementedException();
            }


        }
    }
}
