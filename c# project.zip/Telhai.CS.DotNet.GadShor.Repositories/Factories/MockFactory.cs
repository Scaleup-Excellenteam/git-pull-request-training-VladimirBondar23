﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Telhai.CS.DotNet.GadShor.Repositories.Factories
{
    public class MockFactory : IRepositoryFactory
    {
        public IBugsRepository createBugsRepository()
        {
            return new MockRepository();
        }

        public ICategoryRepository createCategoriesRepository()
        {
            return new MockCategory();
        }
    }
}
