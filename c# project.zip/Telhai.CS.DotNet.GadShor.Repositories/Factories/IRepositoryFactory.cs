﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telhai.CS.DotNet.GadShor.Repositories.Factories
{
    public interface IRepositoryFactory //abstract factory interface
    {
        IBugsRepository createBugsRepository(); 
        ICategoryRepository createCategoriesRepository();
    }
}
