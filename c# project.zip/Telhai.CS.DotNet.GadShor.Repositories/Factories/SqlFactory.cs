﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telhai.CS.DotNet.GadShor.Repositories.Factories
{
    public class SqlFactory : IRepositoryFactory
    {
        public IBugsRepository createBugsRepository()
        {
            return SqlRepository.Instance;
        }

        public ICategoryRepository createCategoriesRepository()
        {
            return SqlCategories.Instance;
        }
    }
}
