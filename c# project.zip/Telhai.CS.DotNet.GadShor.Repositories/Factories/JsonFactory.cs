﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telhai.CS.DotNet.GadShor.Repositories.Factories
{
    internal class JsonFactory : IRepositoryFactory
    {
        public IBugsRepository createBugsRepository()
        {
            return JsonRepository.Instance;
        }

        public ICategoryRepository createCategoriesRepository()
        {
            return JsonCategoryRepository.Instance;
        }
    }
}
