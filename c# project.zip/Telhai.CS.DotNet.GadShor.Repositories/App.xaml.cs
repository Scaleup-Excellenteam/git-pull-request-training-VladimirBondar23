﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Telhai.CS.DotNet.GadShor.Repositories
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
