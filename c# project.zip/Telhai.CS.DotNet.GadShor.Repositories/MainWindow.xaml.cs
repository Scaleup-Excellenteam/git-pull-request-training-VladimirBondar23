﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

using Telhai.CS.DotNet.GadShor.Repositories.Models;
using Telhai.CS.DotNet.GadShor.Repositories.Factories;

namespace Telhai.CS.DotNet.GadShor.Repositories
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// This class manages the main window for displaying, adding, and deleting bugs and categories.
    /// </summary>
    public partial class MainWindow : Window
    {
        // Repository interfaces for interacting with bugs and categories data
        IBugsRepository _bugsRepo;
        ICategoryRepository _categoryRepo;

        // Constructor initializes the main window and sets up the repositories for bugs and categories
        public MainWindow()
        {
            InitializeComponent();
            IRepositoryFactory factory = new SqlFactory();

            // Creating instances of the repository classes using a factory pattern
            _bugsRepo = factory.createBugsRepository();
            _categoryRepo = factory.createCategoriesRepository();

            // Load bugs and categories into the UI
            LoadBugs();
            LoadCategories();
        }

        // Method to load all bugs from the repository and display them in the DataGrid
        private void LoadBugs()
        {
            var bugs = _bugsRepo.GetAll();  // Get all bugs
            var categories = _categoryRepo.GetAllCategories();  // Get all categories

            // Add CategoryName to each bug by matching CategoryId
            foreach (var bug in bugs)
            {
                var category = categories.FirstOrDefault(c => c.Id == bug.CategoryId);
                if (category != null)
                {
                    bug.CategoryName = category.CategoryName;  // Set the category name on the bug
                }
            }

            BugDataGrid.ItemsSource = bugs;  // Bind to the DataGrid with the updated list of bugs
        }


        // Event handler for the Add Bug button click event
        private void AddBug_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Get values from the input fields
                string title = TitleTextBox.Text;
                string description = DescriptionTextBox.Text;
                string status = (StatusComboBox.SelectedItem as ComboBoxItem).Content.ToString();
                Category category = CategoryTreeView.SelectedItem as Category;

                // Create a new bug and add it to the repository
                _bugsRepo.Add(new Bug
                {
                    Title = title,
                    Description = description,
                    Status = status,
                    CategoryId = category.Id
                });

                // Reload the bugs to reflect the newly added bug
                LoadBugs();
            }
            catch (Exception ex)
            {
                // Display any errors that occur during the process
                MessageBox.Show(ex.Message);
            }
        }

        // Event handler for the Delete Bug button click event
        private void DeleteBug_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Check if a bug is selected in the DataGrid
                if (BugDataGrid.SelectedItem is Bug bugItem)
                {
                    // Delete the selected bug from the repository
                    _bugsRepo.Delete(bugItem.BugID);
                    // Reload the bugs after deletion
                    LoadBugs();
                }
            }
            catch (Exception ex)
            {
                // Display any errors that occur during the process
                MessageBox.Show(ex.Message);
            }
        }

        // Event handler for the Categories button click event
        private void Categories_Click(object sender, RoutedEventArgs e)
        {
            // Open the Categories window when the button is clicked
            var categories = new Categories();
            categories.Closed += (s, args) => LoadCategories(); // Reload categories after window is closed
            categories.Show();
        }

        // Method to load categories and build the tree structure for the CategoryTreeView
        private void LoadCategories()
        {
            List<Category> allCategories = _categoryRepo.GetAllCategories(); // Fetch all categories from the repository
            var categoryLookup = allCategories.ToDictionary(c => c.Id);

            // Build hierarchical structure of categories (parent-child relationships)
            foreach (var category in allCategories)
            {
                if (category.ParentCategoryId != 0 && categoryLookup.ContainsKey(category.ParentCategoryId.Value))
                {
                    categoryLookup[category.ParentCategoryId.Value].Children.Add(category); // Add to parent's children
                }
            }

            // Find root categories and set them as the source for the CategoryTreeView
            var rootCategories = allCategories.Where(c => c.ParentCategoryId == 0).ToList();
            CategoryTreeView.ItemsSource = rootCategories;
        }

        // Method to load categories and build the tree structure with bugs assigned to categories
        private List<Category> LoadCategoriesAndBuildTree()
        {
            List<Category> allCategories = _categoryRepo.GetAllCategories();
            List<Bug> allBugs = _bugsRepo.GetAll();

            // Build lookup for easy access
            var categoryLookup = allCategories.ToDictionary(c => c.Id);

            // Assign bugs to their respective categories
            foreach (var bug in allBugs)
            {
                if (categoryLookup.ContainsKey(bug.CategoryId))
                {
                    categoryLookup[bug.CategoryId].Bugs.Add(bug);
                }
            }

            // Build hierarchical structure for categories (parent-child relationships)
            foreach (var category in allCategories)
            {
                if (category.ParentCategoryId != 0 && categoryLookup.ContainsKey(category.ParentCategoryId.Value))
                {
                    categoryLookup[category.ParentCategoryId.Value].Children.Add(category);
                }
            }

            // Find root categories and return them
            var rootCategories = allCategories.Where(c => c.ParentCategoryId == 0).ToList();
            return rootCategories;
        }

        // Method to recursively print category tree structure with bugs to a text writer
        private void PrintCategoryTree(Category category, int indentLevel, TextWriter writer)
        {
            string output = $"{new string(' ', indentLevel * 2)}Category: {category.CategoryName}";
            writer.WriteLine(output);

            // Print bugs under the current category
            foreach (var bug in category.Bugs)
            {
                output = $"{new string(' ', (indentLevel + 1) * 2)}- " + bug.ToString();
                writer.WriteLine(output);
            }

            // Recursively print child categories
            foreach (var childCategory in category.Children)
            {
                PrintCategoryTree(childCategory, indentLevel + 1, writer);
            }
        }

        // Event handler for the Print to File button click event
        private void PrintToFile_Click(object sender, RoutedEventArgs e)
        {
            // Load categories and build tree structure
            List<Category> rootCategories = LoadCategoriesAndBuildTree();

            // Get the path of the solution directory (up two levels from the current directory)
            string solutionDirectory = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\");  // Navigate 3 levels up to the solution root

            // Make sure the path is correct and resolve any relative path issues
            solutionDirectory = System.IO.Path.GetFullPath(solutionDirectory);

            // Define the relative file name
            string relativeFilePath = "categories_output.txt";

            // Combine the solution directory with the relative file path
            string filePath = System.IO.Path.Combine(solutionDirectory, relativeFilePath);

            // Create a new StreamWriter to write the category tree to a file
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                // Print the category tree starting from root categories
                foreach (var rootCategory in rootCategories)
                {
                    PrintCategoryTree(rootCategory, 0, writer);
                }
            }

            
        }


    }
}
