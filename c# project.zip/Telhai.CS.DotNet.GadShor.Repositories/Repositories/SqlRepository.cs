﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

using Telhai.CS.DotNet.GadShor.Repositories.Models;

namespace Telhai.CS.DotNet.GadShor.Repositories
{
    // SqlRepository class implements IBugsRepository for handling bug data with a SQL database
    public class SqlRepository : IBugsRepository
    {
        // Connection string used for connecting to the SQL database
        private string sqlConnectionString = "";

        // Static instance for implementing the Singleton pattern
        private static SqlRepository instance;

        // Singleton instance property to ensure only one instance of SqlRepository is used
        public static IBugsRepository Instance
        {
            get
            {
                if (instance == null)
                {
                    // Create a new instance if it doesn't exist
                    instance = new SqlRepository();
                    return instance;
                }
                else
                {
                    // Return the existing instance
                    return instance;
                }
            }
        }

        // Private constructor to allow setting a custom connection string
        private SqlRepository(string sqlConnectionString)
        {
            this.sqlConnectionString = sqlConnectionString;
        }

        // Private constructor that sets a default connection string
        private SqlRepository()
        {
            sqlConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Bugs;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
        }

        // Method to add a new bug to the database
        public void Add(Bug bugToAdd)
        {
            string query = "INSERT INTO Bugs (Title, Description, Status, CategoryId) VALUES (@Title, @Description, @Status, @CategoryId);";

            // Open a SQL connection and prepare the command
            using (SqlConnection connection = new SqlConnection(sqlConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters to avoid SQL injection
                    command.Parameters.AddWithValue("@Title", bugToAdd.Title);
                    command.Parameters.AddWithValue("@Description", bugToAdd.Description ?? (object)DBNull.Value); // Handle null values
                    command.Parameters.AddWithValue("@Status", bugToAdd.Status);
                    command.Parameters.AddWithValue("@CategoryId", bugToAdd.CategoryId);

                    // Open the connection
                    connection.Open();

                    // Execute the command to insert the bug
                    int rowsAffected = command.ExecuteNonQuery();
                }
            }
        }

        // Method to delete a bug by its ID
        public void Delete(int id)
        {
            string query = "DELETE FROM Bugs WHERE Id = @BugID";

            // Open a SQL connection and prepare the command
            using (SqlConnection connection = new SqlConnection(sqlConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters to avoid SQL injection
                    command.Parameters.AddWithValue("@BugID", id);

                    // Open the connection
                    connection.Open();

                    // Execute the command to delete the bug
                    int rowsAffected = command.ExecuteNonQuery();
                }
            }
        }

        // Method to retrieve a single bug by its ID
        public Bug? Get(int id)
        {
            string query = "SELECT * FROM Bugs WHERE Id = @Id";
            Bug bug = null;

            // Open a SQL connection and prepare the command
            using (SqlConnection connection = new SqlConnection(sqlConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add the bug ID parameter
                    command.Parameters.AddWithValue("@Id", id);
                    connection.Open();

                    // Execute the command and read the result
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            bug = new Bug
                            {
                                // Map the fields from the reader to the Bug object
                                BugID = reader.GetFieldValue<int>("Id"),
                                Title = reader.GetString(1),
                                Description = reader.IsDBNull(2) ? null : reader.GetString(2), // Handle null
                                Status = reader.GetString(3),
                                CategoryId = reader.GetFieldValue<int>("CategoryId")
                            };
                        }
                    }
                }
            }

            // Return the bug or null if not found
            return bug;
        }

        // Method to retrieve all bugs from the database
        public List<Bug> GetAll()
        {
            string query = "SELECT * FROM Bugs";
            List<Bug> bugs = new List<Bug>();

            // Open a SQL connection and prepare the command
            using (SqlConnection connection = new SqlConnection(sqlConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();

                    // Execute the command and read the result set
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            bugs.Add(new Bug
                            {
                                // Map the fields from the reader to the Bug object
                                BugID = reader.GetFieldValue<int>("Id"),
                                Title = reader.GetString(1),
                                Description = reader.IsDBNull(2) ? null : reader.GetString(2), // Handle null
                                Status = reader.GetString(3),
                                CategoryId = reader.GetFieldValue<int>("CategoryId")
                            });
                        }
                    }
                }
            }

            // Return the list of bugs
            return bugs;
        }

        // Method to update a bug's details in the database
        public void Update(int id, Bug bug)
        {
            string query = "UPDATE Bugs SET Title = @Title, Description = @Description, Status = @Status, CategoryId = @Category WHERE Id = @BugID;";

            // Open a SQL connection and prepare the command
            using (SqlConnection connection = new SqlConnection(sqlConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters to update the bug
                    command.Parameters.AddWithValue("@BugID", id);
                    command.Parameters.AddWithValue("@Title", bug.Title);
                    command.Parameters.AddWithValue("@Description", bug.Description ?? (object)DBNull.Value); // Handle null values
                    command.Parameters.AddWithValue("@Status", bug.Status);
                    command.Parameters.AddWithValue("@Category", bug.CategoryId);

                    connection.Open();

                    // Execute the update command
                    int rowsAffected = command.ExecuteNonQuery();
                }
            }
        }
    }
}

