﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Telhai.CS.DotNet.GadShor.Repositories.Models;

namespace Telhai.CS.DotNet.GadShor.Repositories
{
    // Class SqlCategories implements ICategoryRepository for handling category data with a SQL database.
    public class SqlCategories : ICategoryRepository
    {
        // Connection string used for connecting to the SQL database
        private string sqlConnectionString = "";

        // Static instance for implementing the Singleton pattern
        private static SqlCategories instance;

        // Singleton instance property to ensure only one instance of SqlCategories is used
        public static ICategoryRepository Instance
        {
            get
            {
                if (instance == null)
                {
                    // Create a new instance if it doesn't exist
                    instance = new SqlCategories();
                    return instance;
                }
                else
                {
                    // Return the existing instance
                    return instance;
                }
            }
        }

        // Private constructor to allow setting a custom connection string
        private SqlCategories(string sqlConnectionString)
        {
            this.sqlConnectionString = sqlConnectionString;
        }

        // Private constructor that sets a default connection string
        private SqlCategories()
        {
            sqlConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Bugs;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
        }

        // Method to add a category to the database
        public void AddCategory(Category category)
        {
            // Open a SQL connection and prepare the command
            using (var connection = new SqlConnection(sqlConnectionString))
            using (var command = connection.CreateCommand())
            {
                // Define the SQL query for inserting a new category
                command.CommandText = "INSERT INTO Categories (CategoryName, ParentCategoryId) VALUES (@name, @parentId)";
                
                // Add parameters to prevent SQL injection
                command.Parameters.AddWithValue("@name", category.CategoryName);
                command.Parameters.AddWithValue("@parentId", (object)category.ParentCategoryId ?? DBNull.Value);
                
                // Open the connection and execute the insert command
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        // Method to retrieve all categories from the database
        public List<Category> GetAllCategories()
        {
            var categories = new List<Category>();

            // Open a SQL connection and prepare the command
            using (var connection = new SqlConnection(sqlConnectionString))
            using (var command = connection.CreateCommand())
            {
                // Define the SQL query to select all categories
                command.CommandText = "SELECT Id, CategoryName, ParentCategoryId FROM Categories";
                
                // Open the connection and execute the command to fetch data
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    // Loop through the result set and add each category to the list
                    while (reader.Read())
                    {
                        categories.Add(new Category
                        {
                            Id = reader.GetInt32(0),
                            CategoryName = reader.GetString(1),
                            ParentCategoryId = reader.IsDBNull(2) ? 0 : reader.GetInt32(2) // Handle nullable ParentCategoryId
                        });
                    }
                }
            }

            // Return the list of categories
            return categories;
        }

        // Method to delete a category by its ID
        public void DeleteCategory(int categoryId)
        {
            // Open a SQL connection and prepare the command
            using (var connection = new SqlConnection(sqlConnectionString))
            using (var command = connection.CreateCommand())
            {
                // Define the SQL query to delete a category by ID
                command.CommandText = "DELETE FROM Categories WHERE Id = @id";
                
                // Add the category ID parameter
                command.Parameters.AddWithValue("@id", categoryId);
                
                // Open the connection and execute the delete command
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}
