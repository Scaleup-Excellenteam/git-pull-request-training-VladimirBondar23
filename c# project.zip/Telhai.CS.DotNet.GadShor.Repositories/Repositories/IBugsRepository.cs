﻿using Telhai.CS.DotNet.GadShor.Repositories.Models;

namespace Telhai.CS.DotNet.GadShor.Repositories
{
    public interface IBugsRepository
    {
        void Add(Bug bugToAdd);
        void Delete(int id);
        Bug? Get(int id);
        List<Bug> GetAll();
        void Update(int id, Bug bug);
    }
}