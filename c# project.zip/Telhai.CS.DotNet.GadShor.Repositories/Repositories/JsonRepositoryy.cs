﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Telhai.CS.DotNet.GadShor.Repositories.Models;

namespace Telhai.CS.DotNet.GadShor.Repositories
{
    /// <summary>
    /// A repository for managing bug data stored in a JSON file.
    /// Implements the IBugsRepository interface.
    /// </summary>
    public class JsonRepository : IBugsRepository
    {
        private readonly string filePath = "bugs.json"; // Path to the JSON file

        // Properties related to JSON data (not currently used in logic)
        public string JSONString { get; set; }
        public int ItemsCount { get; set; }
        public int FileSize { get; set; }

        private static JsonRepository jsonFileRepository; // Singleton instance

        /// <summary>
        /// Provides a single instance of JsonRepository (Singleton pattern).
        /// </summary>
        public static IBugsRepository Instance
        {
            get
            {
                if (jsonFileRepository == null)
                {
                    jsonFileRepository = new JsonRepository();
                }
                return jsonFileRepository;
            }
        }

        /// <summary>
        /// Provides a single instance of JsonRepository with a custom file path.
        /// </summary>
        /// <param name="filePath">The JSON file path.</param>
        public static IBugsRepository getInstance(string filePath)
        {
            if (jsonFileRepository == null)
            {
                jsonFileRepository = new JsonRepository(filePath);
            }
            return jsonFileRepository;
        }

        /// <summary>
        /// Private constructor to prevent direct instantiation.
        /// Uses default file path.
        /// </summary>
        private JsonRepository() { }

        /// <summary>
        /// Private constructor that allows setting a custom file path.
        /// </summary>
        /// <param name="filePath">The JSON file path.</param>
        private JsonRepository(string filePath)
        {
            this.filePath = filePath;
        }

        /// <summary>
        /// Retrieves all bugs from the JSON file.
        /// </summary>
        /// <returns>A list of bugs, or an empty list if the file does not exist.</returns>
        public List<Bug> GetAll()
        {
            if (!File.Exists(filePath))
                return new List<Bug>();

            string json = File.ReadAllText(filePath);
            return JsonConvert.DeserializeObject<List<Bug>>(json) ?? new List<Bug>();
        }

        /// <summary>
        /// Adds a new bug to the JSON file.
        /// Assigns a unique ID if not already set.
        /// </summary>
        /// <param name="bug">The bug to add.</param>
        public void Add(Bug bug)
        {
            var bugs = GetAll();
            bug.BugID = bugs.Any() ? bugs.Max(b => b.BugID) + 1 : 1; // Auto-increment ID
            bugs.Add(bug);
            SaveToFile(bugs);
        }

        /// <summary>
        /// Updates an existing bug's details.
        /// </summary>
        /// <param name="id">The ID of the bug to update.</param>
        /// <param name="bug">The updated bug object.</param>
        public void Update(int id, Bug bug)
        {
            var bugs = GetAll();
            var existingBug = bugs.FirstOrDefault(b => b.BugID == bug.BugID);
            if (existingBug != null)
            {
                existingBug.Title = bug.Title;
                existingBug.Description = bug.Description;
                existingBug.Status = bug.Status;
                SaveToFile(bugs);
            }
        }

        /// <summary>
        /// Deletes a bug by its ID.
        /// </summary>
        /// <param name="bugId">The ID of the bug to remove.</param>
        public void Delete(int bugId)
        {
            var bugs = GetAll();
            bugs.RemoveAll(b => b.BugID == bugId);
            SaveToFile(bugs);
        }

        /// <summary>
        /// Saves the updated bug list back to the JSON file.
        /// </summary>
        /// <param name="bugs">The list of bugs to be saved.</param>
        private void SaveToFile(List<Bug> bugs)
        {
            string json = JsonConvert.SerializeObject(bugs, Formatting.Indented);
            File.WriteAllText(filePath, json);
        }

        /// <summary>
        /// Retrieves a specific bug by its ID.
        /// </summary>
        /// <param name="id">The bug ID.</param>
        /// <returns>The matching bug, or null if not found.</returns>
        public Bug Get(int id)
        {
            var bugs = GetAll();
            return bugs.Find(b => b.BugID == id);
        }

        /// <summary>
        /// Placeholder for an unimplemented update method.
        /// </summary>
        /// <param name="id">The ID of the bug to update.</param>
        public void Update(int id)
        {
            throw new NotImplementedException();
        }
    }
}

