﻿using System;
using System.Collections.Generic;
using System.Linq;
using Telhai.CS.DotNet.GadShor.Repositories.Models;

namespace Telhai.CS.DotNet.GadShor.Repositories
{
    /// <summary>
    /// A mock implementation of IBugsRepository for testing purposes.
    /// Stores bug data in memory instead of a database or file.
    /// </summary>
    class MockRepository : IBugsRepository
    {
        // In-memory list to store bugs
        private List<Bug> _listBugs;

        /// <summary>
        /// Initializes a new instance of the MockRepository class.
        /// </summary>
        public MockRepository()
        {
            _listBugs = new List<Bug>();
        }

        /// <summary>
        /// Adds a new bug to the repository.
        /// Automatically assigns a unique ID if not already set.
        /// </summary>
        /// <param name="bugToAdd">The bug to be added.</param>
        public void Add(Bug bugToAdd)
        {
            bugToAdd.BugID = _listBugs.Any() ? _listBugs.Max(b => b.BugID) + 1 : 1; // Auto-increment ID
            _listBugs.Add(bugToAdd);
        }

        /// <summary>
        /// Deletes a bug from the repository by its ID.
        /// </summary>
        /// <param name="id">The ID of the bug to remove.</param>
        public void Delete(int id)
        {
            _listBugs.RemoveAll(b => b.BugID == id);
        }

        /// <summary>
        /// Retrieves a specific bug by its ID.
        /// </summary>
        /// <param name="id">The ID of the bug to retrieve.</param>
        /// <returns>The bug if found, otherwise null.</returns>
        public Bug? Get(int id)
        {
            return _listBugs.FirstOrDefault(b => b.BugID == id);
        }

        /// <summary>
        /// Updates an existing bug's details.
        /// </summary>
        /// <param name="id">The ID of the bug to update.</param>
        /// <param name="bug">The new bug details.</param>
        public void Update(int id, Bug bug)
        {
            var existingBug = _listBugs.FirstOrDefault(b => b.BugID == id);
            if (existingBug != null)
            {
                existingBug.Title = bug.Title;
                existingBug.Description = bug.Description;
                existingBug.Status = bug.Status;
            }
        }

        /// <summary>
        /// Retrieves all bugs in the repository.
        /// </summary>
        /// <returns>A list of all stored bugs.</returns>
        public List<Bug> GetAll()
        {
            return _listBugs;
        }
    }
}

