﻿using System.Collections.Generic;
using System.Linq;
using Telhai.CS.DotNet.GadShor.Repositories;
using Telhai.CS.DotNet.GadShor.Repositories.Models;

/// <summary>
/// A mock implementation of ICategoryRepository for testing purposes.
/// Stores categories in memory instead of a database or file.
/// </summary>
class MockCategory : ICategoryRepository
{
    // In-memory list to store categories
    private readonly List<Category> _categories = new();

    /// <summary>
    /// Adds a new category to the list.
    /// Automatically assigns a unique ID if not already set.
    /// </summary>
    /// <param name="category">The category to add.</param>
    public void AddCategory(Category category)
    {
        category.Id = _categories.Any() ? _categories.Max(c => c.Id) + 1 : 1; // Auto-increment ID
        _categories.Add(category);
    }

    /// <summary>
    /// Deletes a category from the list by its ID.
    /// </summary>
    /// <param name="categoryId">The ID of the category to remove.</param>
    public void DeleteCategory(int categoryId)
    {
        _categories.RemoveAll(c => c.Id == categoryId);
    }

    /// <summary>
    /// Retrieves all categories stored in memory.
    /// </summary>
    /// <returns>A list of categories.</returns>
    public List<Category> GetAllCategories() => _categories;
}
