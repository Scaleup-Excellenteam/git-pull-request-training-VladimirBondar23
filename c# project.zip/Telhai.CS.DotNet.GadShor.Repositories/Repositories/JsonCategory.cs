﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Telhai.CS.DotNet.GadShor.Repositories;
using Telhai.CS.DotNet.GadShor.Repositories.Models;

/// <summary>
/// A repository for managing category data stored in a JSON file.
/// Implements the ICategoryRepository interface.
/// </summary>
public class JsonCategoryRepository : ICategoryRepository
{
    private readonly string filePath = "categories.json"; // File path for storing category data
    private static JsonCategoryRepository instance; // Singleton instance

    /// <summary>
    /// Provides a single instance of JsonCategoryRepository (Singleton pattern).
    /// </summary>
    public static ICategoryRepository Instance => instance ??= new JsonCategoryRepository();

    /// <summary>
    /// Private constructor to enforce Singleton pattern.
    /// </summary>
    private JsonCategoryRepository() { }

    /// <summary>
    /// Retrieves all categories from the JSON file.
    /// </summary>
    /// <returns>A list of categories, or an empty list if the file does not exist or is empty.</returns>
    public List<Category> GetAllCategories()
    {
        return File.Exists(filePath)
            ? JsonConvert.DeserializeObject<List<Category>>(File.ReadAllText(filePath)) ?? new List<Category>()
            : new List<Category>();
    }

    /// <summary>
    /// Adds a new category to the JSON file.
    /// Assigns a unique ID if not already set.
    /// </summary>
    /// <param name="category">The category to add.</param>
    public void AddCategory(Category category)
    {
        var categories = GetAllCategories();
        category.Id = categories.Any() ? categories.Max(c => c.Id) + 1 : 1; // Auto-increment ID
        categories.Add(category);
        SaveToFile(categories);
    }

    /// <summary>
    /// Deletes a category by its ID.
    /// </summary>
    /// <param name="categoryId">The ID of the category to remove.</param>
    public void DeleteCategory(int categoryId)
    {
        var categories = GetAllCategories();
        categories.RemoveAll(c => c.Id == categoryId);
        SaveToFile(categories);
    }

    /// <summary>
    /// Saves the updated category list back to the JSON file.
    /// </summary>
    /// <param name="categories">The list of categories to be saved.</param>
    private void SaveToFile(List<Category> categories)
    {
        File.WriteAllText(filePath, JsonConvert.SerializeObject(categories, Formatting.Indented));
    }
}

