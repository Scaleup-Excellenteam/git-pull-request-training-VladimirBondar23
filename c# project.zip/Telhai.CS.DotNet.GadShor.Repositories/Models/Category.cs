﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telhai.CS.DotNet.GadShor.Repositories.Models
{
    public class Category
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
        public int? ParentCategoryId { get; set; }
        public ObservableCollection<Category> Children { get; set; } = new();
        public List<Bug> Bugs { get; set; } = new();
        public override string ToString()
        {
            return $"ID: {Id}, CategoryName: {CategoryName}, ParentCategory: {ParentCategoryId}";
        }
    }
}
