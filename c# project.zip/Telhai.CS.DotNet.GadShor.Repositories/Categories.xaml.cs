﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Telhai.CS.DotNet.GadShor.Repositories.Models;

namespace Telhai.CS.DotNet.GadShor.Repositories
{
    /// <summary>
    /// Interaction logic for Categories.xaml
    /// This class handles the interaction for the Categories window,
    /// including displaying, adding, and deleting categories.
    /// </summary>
    public partial class Categories : Window
    {
        // Repository for interacting with the category data (e.g., adding, deleting categories)
        private ICategoryRepository repo;

        // Constructor for initializing the Categories window and setting up the repository
        public Categories()
        {
            InitializeComponent();
            // Assigning the repository instance (Singleton pattern) for database interaction
            repo = SqlCategories.Instance;
            // Loading categories from the repository and displaying them in the data grid
            LoadCategories();
        }

        // Method to load categories from the repository and display them in the data grid
        private void LoadCategories()
        {
            // Retrieve all categories from the repository
            var categories = repo.GetAllCategories();
            // Set the categories list as the source of data for the DataGrid
            BugDataGrid.ItemsSource = categories;
        }

        // Event handler for the delete button click event
        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Check if a category is selected in the DataGrid
                if (BugDataGrid.SelectedItem is Category category)
                {
                    // Delete the selected category from the repository
                    repo.DeleteCategory(category.Id);
                    // Reload the categories after deletion
                    LoadCategories();
                }
            }
            catch (Exception ex)
            {
                // Display any errors in a message box
                MessageBox.Show(ex.Message);
            }
        }

        // Event handler for the add button click event
        private void add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Parse the parent category ID from the input field (if available)
                int parentId = int.TryParse(ParentCategoryTextBox.Text?.Trim(), out var result) ? result : 0;
                // Get the category name from the input field
                string name = CategoryNameTextBox.Text.ToString();

                // Add a new category using the data from the input fields
                repo.AddCategory(new Category
                {
                    CategoryName = name,
                    ParentCategoryId = parentId
                });

                // Reload the categories to reflect the newly added category
                LoadCategories();
            }
            catch (Exception ex)
            {
                // Display any errors in a message box
                MessageBox.Show(ex.Message);
            }
        }
    }
}

