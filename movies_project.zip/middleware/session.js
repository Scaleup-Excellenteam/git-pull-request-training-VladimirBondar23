const session = require('express-session');

module.exports = session({
    secret: '12345678',
    resave: false,
    saveUninitialized: true,
    cookie: {
        secure: false,
        httpOnly: true,
        maxAge: 1000 * 60 * 60 * 24, // 1 day
    },
});
