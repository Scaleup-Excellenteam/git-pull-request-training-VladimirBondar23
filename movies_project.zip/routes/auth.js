const express = require('express');
const mongoose = require('mongoose');
const User = require('../models/User');
const path = require('path'); 

const router = express.Router();

router.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../Client/login.html'));
});

router.get('/register', (req, res) => {                                 //some checks for the password
  res.sendFile(path.join(__dirname, '../Client/register.html'));
});

router.post('/register', async (req, res) => {
  const { username, email, password, password2 } = req.body;
  if (password !== password2) {
    return res.status(400).json({ message: 'Passwords don\'t match' });
  }
  if (password.length < 6 || password.length > 15) {
    return res.status(400).json({ message: 'Password must be between 6 and 15 characters' });
  }
  if (!(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/.test(password))) {
    return res.status(400).json({ message: 'Password must contain one number, one big letter, one small letter' });
  }
  if (username.length > 50) {
    return res.status(400).json({ message: 'Username too long' });
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ message: 'Invalid email format.' });
  }
  try {
    const emailExists = await User.findOne({ email });
    if (emailExists) {
      return res.status(400).json({ message: 'Email is already registered.' });
    }
    const newUser = new User({ username, email, password, favorites: [] });
    await newUser.save();                   //save user in DB

    return res.status(200).json({ message: 'Registration successful!' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Server error.' });
  }
});

router.post('/login', async (req, res) => { // check if user exists in DB and save the user in a session
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user || user.password !== password) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    req.session.user = { username: user.username, email: user.email, favorites: user.favorites };
    return res.status(200).json({ message: 'Login successful' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Server error.' });
  }
});

module.exports = router;
