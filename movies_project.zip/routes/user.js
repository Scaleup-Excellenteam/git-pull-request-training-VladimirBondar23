const express = require('express');
const User = require('../models/User');
const path = require('path');
const router = express.Router();

// Route to get the current logged-in user
router.get('/current-user', (req, res) => {
  // If user is not logged in, return 401 status with a message
  if (!req.session.user) {
    return res.status(401).json({ message: 'Not logged in' });
  }
  // If logged in, return user details
  res.status(200).json(req.session.user);
});

// Route to update user favorites
router.post('/update-user', async (req, res) => {
  // Check if the user is logged in
  if (!req.session.user) {
    return res.status(401).json({ message: 'Not logged in' });
  }

  const { favorites } = req.body;

  try {
    // Find and update the user's favorites in the database
    const updatedUser = await User.findOneAndUpdate(
      { email: req.session.user.email },  // Search by email
      { favorites },                     // Update the favorites
      { new: true }                      // Return the updated user
    );

    // If user not found, return a 404 error
    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found.' });
    }

    // Update session data with new favorites
    req.session.user.favorites = updatedUser.favorites;

    // Return success message
    res.status(200).json({ message: 'Favorites updated successfully.' });
  } catch (error) {
    // Log and return server error if something goes wrong
    console.error(error);
    res.status(500).json({ message: 'Server error.' });
  }
});

module.exports = router;


