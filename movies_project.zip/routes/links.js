const express = require('express');
const router = express.Router();
const sqlite3 = require('sqlite3').verbose();

// Connect to SQLite database
const db = new sqlite3.Database('./movieLinks.db', (err) => {
    if (err) {
      console.error('Could not open database:', err.message);
    } else {
      console.log('Connected to the SQLite database.');
    }
  });
  
  // Create the required tables if they don't already exist
  db.run(`
    CREATE TABLE IF NOT EXISTS public_links (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  movie_id TEXT,
  link_name TEXT,
  link_description TEXT,
  link_url TEXT,
  click_count INTEGER DEFAULT 0,  -- Initialize click_count to 0
  created_by TEXT                 -- Store the name of the user who created the link
)
`
);

router.get('/all', (req, res) => {
    const sql = `SELECT * FROM public_links`; // Select all links

    db.all(sql, [], (err, rows) => {
        if (err) {
            console.error('Database error:', err.message); // Log DB errors
            return res.status(500).json({ error: err.message });
        }
        
        res.status(200).json(rows); // Return the list of all links
    });
});


// Route to add a new link for a specific movie
router.post('/:movieId', (req, res) => {
    // Destructure data from the request body
    const { link_name, link_description, link_url, created_by } = req.body;
    const { movieId } = req.params;
  
    // SQL query to insert a new link into the public_links table
    const sql = `
      INSERT INTO public_links (movie_id, link_name, link_description, link_url, created_by)
      VALUES (?, ?, ?, ?, ?)
    `;
    const params = [movieId, link_name, link_description, link_url, created_by];
  
    // Execute the SQL query to add the link
    db.run(sql, params, function (err) {
      if (err) {
        // Handle errors during insertion
        return res.status(500).json({ error: err.message });
      }
      // Return success message with the inserted link's ID
      res.status(201).json({ message: 'Link added successfully', id: this.lastID });
    });
});
  
// Route to get all links for a specific movie
router.get('/:movieId', (req, res) => {
    const { movieId } = req.params;
  
    // SQL query to retrieve links for the given movie
    const sql = `SELECT * FROM public_links WHERE movie_id = ?`;
    
    // Execute the SQL query to get the links
    db.all(sql, [movieId], (err, rows) => {
        if (err) {
            // Log DB error and return a 500 error response
            console.error('Database error:', err.message);
            return res.status(500).json({ error: err.message });
        }
        
        // Return the fetched rows (links) as a response
        res.status(200).json(rows);
    });
});
  
// Route to update the click count of a link for a specific movie
router.put('/:movieId', (req, res) => {
    const { link_name, link_description, link_url } = req.body;
    const { movieId } = req.params;

    // SQL query to find the link based on movie_id and link details
    const sql = `SELECT * FROM public_links WHERE movie_id = ? AND link_name = ? AND link_description = ? AND link_url = ?`;
  
    // Execute the query to check if the link exists
    db.get(sql, [movieId, link_name, link_description, link_url], (err, row) => {
      if (err) {
        // Handle errors during the query execution
        return res.status(500).json({ error: err.message });
      }
      if (!row) {
        // If the link is not found, return a 400 error
        return res.status(400).json({ message: 'Link not found' });
      }
  
      // SQL query to increment the click_count of the found link
      const updateSql = `UPDATE public_links SET click_count = click_count + 1 WHERE id = ?`;
      
      // Execute the update query
      db.run(updateSql, [row.id], function (err) {
        if (err) {
          // Handle errors during the update operation
          return res.status(500).json({ error: err.message });
        }
        // Return success message after the click count update
        res.status(200).json({ message: 'Click count updated successfully' });
      });
    });
});

// Route to delete a link for a specific movie
router.delete('/:movieId', (req, res) => {
    const { link_name, link_description, link_url } = req.body;
    const { movieId } = req.params;
  
    // SQL query to find the link based on movie_id and link details
    const sql = `SELECT * FROM public_links WHERE movie_id = ? AND link_name = ? AND link_description = ? AND link_url = ?`;
  
    // Execute the query to check if the link exists
    db.get(sql, [movieId, link_name, link_description, link_url], (err, row) => {
      if (err) {
        // Handle errors during the query execution
        return res.status(500).json({ error: err.message });
      }
      if (!row) {
        // If the link is not found, return a 400 error
        return res.status(400).json({ message: 'Link not found' });
      }
  
      // SQL query to delete the link from the public_links table
      const deleteSql = `DELETE FROM public_links WHERE id = ?`;
      
      // Execute the delete query
      db.run(deleteSql, [row.id], function (err) {
        if (err) {
          // Handle errors during the delete operation
          return res.status(500).json({ error: err.message });
        }
        // Return success message after the link is deleted
        res.status(200).json({ message: 'Link deleted successfully' });
      });
    });
});

module.exports = router;
