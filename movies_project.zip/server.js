const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const sessionMiddleware = require('./middleware/session');

const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const favoritesRoutes = require('./routes/favorites_routes');
const linksRoutes = require('./routes/links')

const app = express();
const PORT = 3000;

// Middleware
app.use(express.static(path.join(__dirname, 'Client')));
app.use('/styles', express.static(path.join(__dirname, 'styles')));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(sessionMiddleware);

// MongoDB Connection
const mongoURI = 'mongodb+srv://vdecbel:vovavova@users.vhitd.mongodb.net/?retryWrites=true&w=majority&appName=users';
mongoose.connect(mongoURI)
  .then(() => console.log('MongoDB connected successfully'))
  .catch(err => console.error('MongoDB connection error:', err));

// Routes
app.use('/auth', authRoutes);
app.use('/user', userRoutes);
app.use('/favorites', favoritesRoutes);
app.use('/links', linksRoutes);

// Entry Points
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'Client/entrance.html'));
});

app.get('/with_links', (req, res) => {
    res.sendFile(path.join(__dirname, 'Client/movies_with_links.html'));
});

app.get('/index2', (req, res) => {
    res.sendFile(path.join(__dirname, 'Client/index2.html'));
});
app.get('/admin_page', (req, res) => {

    res.sendFile(path.join(__dirname, 'Client/admin_page.html'));
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});



