const mongoose = require('mongoose');

const favoriteSchema = new mongoose.Schema({      // a Schema for every User in mongoDB
  id: String,
  title: String,
  year: String,
  plot: String,
  imdbid: String,
  poster: String,
  director: String,
  genre: String,
  actors: String,
  rating: String,
  links: [
    {
      name: String,
      description: String,
      url: String,
    },
  ],
});

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, maxlength: 50 },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  favorites: [favoriteSchema],
});

module.exports = mongoose.model('User', userSchema);
