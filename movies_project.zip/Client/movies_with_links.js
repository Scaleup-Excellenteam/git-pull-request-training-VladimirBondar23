
document.addEventListener("DOMContentLoaded", async function () {

    const container = document.getElementById("movies-container");

    try {
        const linksResponse = await fetch('/links/all');
        if (linksResponse.ok) {
            const links = await linksResponse.json(); // List of all links

            // Group links by movie_id and select the one with the highest click_count
            const groupedLinks = groupLinksByMovie(links);

            // Render the cards for each movie
            RenderLinksCard(groupedLinks, container);
        } else {
            console.error('Failed to fetch links');
        }
    } catch (err) {
        console.error('Error fetching links:', err);
    }
});


async function RenderLinksCard(links, container) {
    let movies = [];
    for (const link of links) {
        let imdb = link.movie_id;
        const movie = await MoviesAPI.fetchMoviesDetails(imdb); //fetch movie for each link
        movies.push({ movie, link_url: link.link_url }); // Store both movie and link_url
    }

    // Now render cards with the link replaced by the URL
    movies.forEach(({ movie, link_url }) => {
        const card = `
            <div class="col-md-3 mb-4">
                <div class="card" style="width: 18rem;">
                    <img src="${movie.poster}" class="card-img-top" alt="${movie.title}">
                    <div class="card-body">
                        <h5 class="card-title">${movie.title}</h5>
                        <p class="card-text">${movie.year}</p>
                        <a href="details.html?imdbID=${movie.imdbid}&prev=${' '}" class="btn btn-primary">Details</a>
                        <a href="${link_url}" target="_blank" class="btn btn-primary">Visit Link</a> <!-- Replaced button with link -->
                    </div>
                </div>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', card);
    });
}



document.getElementById('favorites-btn').addEventListener('click', () => {
    window.location.href = '/favorites';
});

function groupLinksByMovie(links) {     //group links by movie and leave only those that have the highest click_count
    const grouped = {};

    links.forEach(link => {
        const { movie_id, click_count } = link;

        if (!grouped[movie_id]) {
            grouped[movie_id] = link;
        } else if (click_count > grouped[movie_id].click_count) {
            grouped[movie_id] = link; // Update to the link with higher click_count
        }
    });

    return Object.values(grouped); // Return only the links with the highest click_count for each movie
}