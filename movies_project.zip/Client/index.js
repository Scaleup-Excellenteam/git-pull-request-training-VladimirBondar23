


let searchInputElement = null;
document.addEventListener("DOMContentLoaded", async function(){
    searchInputElement = document.getElementById("search-txt");
    try{
    searchInputElement.addEventListener("input", inputSearch);
    }
    catch{

    }
        
    const query1 = new URLSearchParams(window.location.search).get('query');        
    if (query1) {
        searchInputElement.value = query1
        const movies = await MoviesAPI.fetchMovies(query1);
        MoviesAPI.RenderMoviesCard(movies, document.getElementById("movies-container"));
        
    }
    try {
        const response = await fetch('/user/current-user');
        if (response.ok) {
            const { username, email, favorites } = await response.json();
            
            if (email === "vdecbel@gmail.com") {    //if user is admin (my email address) password is Vovavova2
                document.getElementById('header-title').innerText = `Welcome, Admin`;

                // Add the Admin Page button
                const headerButtonsContainer = document.querySelector('.header-buttons');
                const adminPageButton = document.createElement('button');
                adminPageButton.textContent = 'Admin Page';
                adminPageButton.classList.add('btn', 'btn-primary');
                adminPageButton.addEventListener('click', () => {
                    window.location.href = '/admin_page';
                });
                headerButtonsContainer.appendChild(adminPageButton);
            } else {
                document.getElementById('header-title').innerText = `Welcome, ${username}`;
            }
        } else {
            // Handle the error if response is not OK
        }
    } catch (err) {
        console.error('Failed to fetch user:', err);
        window.location.href = '/';
    }



});

function inputSearch(){
    let containerMoviesDiv = document.getElementById('movies-container')
    let query = searchInputElement.value
    if (query.length > 3){
        containerMoviesDiv.innerHTML = ""
        MoviesAPI.fetchMovies(query).then(movies => MoviesAPI.RenderMoviesCard(movies, containerMoviesDiv))
    }
    else{
        containerMoviesDiv.innerHTML = ""
    }
}

document.getElementById('favorites-btn').addEventListener('click', ()=>{
    window.location.href = '/favorites'
})

