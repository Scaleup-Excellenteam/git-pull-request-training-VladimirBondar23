class Link {
    constructor(name, description, url) {
        this.name = name;
        this.description = description;
        this.url = url;
    }
}

let movie = null;
document.addEventListener("DOMContentLoaded", async function () {
    let user = null;

    try {
        // Fetch current user data
        const response = await fetch('/user/current-user');
        if (response.ok) {
            user = await response.json(); // { username, email, favorites }
        }
    } catch (err) {
        console.error('Failed to fetch user:', err);
        return;
    }
    const isAdmin = user.email === "vdecbel@gmail.com"? true : false  //check if user is admin (my email address) password is Vovavova2
    const imdb = new URLSearchParams(window.location.search).get('imdbID');
    movie = await MoviesAPI.fetchMoviesDetails(imdb);
    document.getElementById("hdr").innerText = movie.title;

    // Check if the movie is already in the user's favorites
    let isFavorite = user.favorites.some((fav) => fav.imdbid === imdb);
    const favoriteButtonText = isFavorite ? "Remove from favorites" : "Add to favorites";

    // Populate movie details
    document.getElementById("movie-details").innerHTML = `
    <div class="row">
        <div class="col md-6">
            <img src="${movie.poster}" alt="${movie.title} Poster" class="img-fluid rounded border">
        </div>
        <div class="col md-6">
            <ul class="list-group list-group-flush mt-3">
                <li class="list-group-item"><strong>Year: </strong>${movie.year}</li>
                <li class="list-group-item"><strong>Genre: </strong>${movie.genre}</li>
                <li class="list-group-item"><strong>Director: </strong>${movie.director}</li>
                <li class="list-group-item"><strong>Actors: </strong>${movie.actors}</li>
                <li class="list-group-item"><strong>Plot: </strong>${movie.plot}</li>
                <li class="list-group-item"><strong>Rating: </strong>${movie.rating}</li>
                <li class="list-group-item" id="links">
                    <strong>Links:</strong>
                    <div id="movie-links"></div>
                    <div class="d-flex gap-2">
                        <input type="text" id="link-name" class="form-control" placeholder="Link Name">
                        <input type="text" id="link-description" class="form-control" placeholder="Link Description">
                        <input type="text" id="link-input" class="form-control" placeholder="Link URL">

                        <!-- Dropdown to choose visibility -->
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-secondary dropdown-toggle" id="link-visibility-btn" data-bs-toggle="dropdown" aria-expanded="false">
                                Public
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="link-visibility-btn">
                                <li><a class="dropdown-item" href="#" id="public-link">Public</a></li>
                                <li><a class="dropdown-item" href="#" id="private-link">Private</a></li>
                            </ul>
                        </div>
                    </div>
                    <button id="add-link-button" class="btn btn-primary mt-2">Add Link</button>
                </li>
            </ul>
            <div class="mt-4">
                <button id="favorite-button" class="btn btn-primary">${favoriteButtonText}</button>
                <button id="back-button" class="btn btn-secondary">Back to Search</button>
            </div>
        </div>
    </div>
`;

let visibility = 'public'; // Default visibility is public

// Event listeners for visibility toggle
document.getElementById('public-link').addEventListener('click', function() {
    visibility = 'public';
    document.getElementById('link-visibility-btn').innerText = 'Public';
});

document.getElementById('private-link').addEventListener('click', function() {
    visibility = 'private';
    document.getElementById('link-visibility-btn').innerText = 'Private';
});




async function fetchPublicLinks(imdb) {             //fetch links from database by sending a get request to links router
    const response = await fetch(`/links/${imdb}`);
    if (response.ok) {
        const links = await response.json();
        displayPublicLinks(links);
    } else {
        console.error('Failed to fetch public links:', response.statusText);
    }
}

function displayPublicLinks(links, itemsPerPage = 5) {
    const publicLinksList = document.getElementById('public-links-list');
    const paginationContainer = document.getElementById('pagination');
    let currentPage = 1;

    // Sort links by click_count in descending order
    links.sort((a, b) => b.click_count - a.click_count);

    // Function to render a specific page
    const renderPage = (page) => {
        currentPage = page;
        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const paginatedLinks = links.slice(start, end);

        // Clear the list and render the current page
        publicLinksList.innerHTML = '';
        if (paginatedLinks.length === 0) {
            publicLinksList.innerHTML = '<li class="list-group-item">No public links available for this movie.</li>';
        } else {
            paginatedLinks.forEach((link) => {
                const linkItem = document.createElement('li');
                linkItem.classList.add('list-group-item');

                // Create the link element
                linkItem.innerHTML = `
                    <strong>${link.link_name}:</strong> ${link.link_description} - 
                    <a href="${link.link_url}" target="_blank" class="public-link">${link.link_url}</a> 
                    <span class="badge bg-info">${link.click_count} clicks</span>
                `;
                
                // Check if the current user created this link or he's an admin in order to be able to remove the public link
                if (link.created_by === user.username || isAdmin) {
                    const removeButton = document.createElement('button');
                    removeButton.textContent = 'Remove';
                    removeButton.classList.add('btn', 'btn-danger', 'btn-sm', 'float-end');
                    removeButton.addEventListener('click', async () => {
                        try {
                            await deleteLink(link);
                            display_links()
                            linkItem.remove();
                        } catch (error) {
                            console.error('Failed to remove link:', error);
                        }
                    });
                    linkItem.appendChild(removeButton);
                }

                // Add click event to update click count
                linkItem.querySelector('a.public-link').addEventListener('click', async (e) => {
                    e.preventDefault();
                    try {
                        await incrementClickCount(link);
                        window.open(link.link_url, '_blank');
                    } catch (error) {
                        console.error('Failed to update click count:', error);
                    }
                });

                publicLinksList.appendChild(linkItem);
            });
        }
    };

    // Function to render pagination controls   (1,2,3 pages for long list of links)
    const renderPagination = () => {
        paginationContainer.innerHTML = '';
        const totalPages = Math.ceil(links.length / itemsPerPage);

        for (let i = 1; i <= totalPages; i++) {
            const pageButton = document.createElement('button');
            pageButton.textContent = i;
            pageButton.classList.add('btn', 'btn-sm', 'mx-1', currentPage === i ? 'btn-primary' : 'btn-secondary');
            pageButton.addEventListener('click', () => {
                renderPage(i);
                renderPagination();
            });
            paginationContainer.appendChild(pageButton);
        }
    };

    // Initial render
    renderPage(1);
    renderPagination();
}


async function deleteLink(link) {       //delete a link from SQL
    try {
        const response = await fetch(`/links/${imdb}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                link_name: link.link_name,
                link_description: link.link_description,
                link_url: link.link_url,
            }),
        });

        if (!response.ok) {
            throw new Error(`Failed to delete link: ${response.statusText}`);
        }


    } catch (error) {
        console.error('Error deleting link:', error);
    }
}

async function incrementClickCount(link) {
    try {
        // Call the PUT method to increment the click count
        const response = await fetch(`/links/${imdb}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                link_name: link.link_name,
                link_description: link.link_description,
                link_url: link.link_url,
            }),
        });

        if (!response.ok) {
            throw new Error(`Failed to increment click count: ${response.statusText}`);
        }

        
        // Refresh the displayed links after updating
        display_links();
    } catch (error) {
        console.error('Error updating click count:', error);
    }
}





document.getElementById('add-link-button').addEventListener("click", async function () {
    // Get input values and trim whitespace
    const name = document.getElementById('link-name').value.trim();
    const description = document.getElementById('link-description').value.trim();
    const url = document.getElementById('link-input').value.trim();
    const createdBy = user.username;
    
    if (!name || !description || !url) return; // Prevent empty submissions

    if (!user.favorites) user.favorites = [];
    let movieIndex = user.favorites.findIndex((fav) => fav.imdbid === imdb);

    if (movieIndex !== -1) {
        let movie = user.favorites[movieIndex];
        const newLink = new Link(name, description, url);

        if (visibility === 'private') {
            // Add link if it's not already in the list
            if (!movie.links.some((link) => link.url === newLink.url)) {
                movie.links.push(newLink);
                await updateUserFavorites(user.email, user.favorites); // Update on server
            }
        } else if (visibility === 'public') {
            await savePublicLink(imdb, newLink, createdBy); // Save public link to database
        }
        display_links(); // Refresh the displayed links
    }

    // Clear input fields after submission
    document.getElementById('link-name').value = "";
    document.getElementById('link-description').value = "";
    document.getElementById('link-input').value = "";
});

async function savePublicLink(imdb, link, created_by) {
    try {
        // Send POST request to save public link in the database
        await fetch(`/links/${imdb}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                link_name: link.name,
                link_description: link.description,
                link_url: link.url,
                created_by: created_by,
            }),
        });
    } catch (err) {
        console.error('Failed to add a link', err);
    }
}

let movie_links_div = document.getElementById('movie-links');
let links = document.getElementById('links');

// Clear links section if the movie is not a favorite
if (!isFavorite) {
    links.innerHTML = "";
}
// Display links if the movie is in favorites
if (isFavorite) {
    display_links();
}

function remove_link(linkToRemoveUrl) {
    let movieIndex = user.favorites.findIndex((fav) => fav.imdbid === imdb);

    if (movieIndex !== -1) {
        let movie = user.favorites[movieIndex];
        // Remove the selected link
        movie.links = movie.links.filter((link) => link.url !== linkToRemoveUrl);
        user.favorites[movieIndex] = movie;
        updateUserFavorites(user.email, user.favorites); // Update on server
        display_links(); // Refresh displayed links
    }
}

async function display_links() {
    movie_links_div.innerHTML = ""; // Clear existing links

    let movieIndex = user.favorites.findIndex((fav) => fav.imdbid === imdb);
    let movie = user.favorites[movieIndex];
    let movie_links = movie.links || [];

    for (let index = 0; index < movie_links.length; index++) {
        const link = movie_links[index];
        const linkId = `link${index}`;
        let linkElement = document.createElement("li");
        linkElement.id = linkId;
        linkElement.classList.add("list-group-item");

        // Create link element with remove button
        linkElement.innerHTML = `
            <div>
                <strong>${link.name}:</strong> ${link.description} - 
                <a href="${link.url}" target="_blank">${link.url}</a>
                <button class="remove-link-btn btn btn-danger btn-sm ml-2" data-link="${link.url}" data-id="${linkId}">Remove</button>
            </div>
        `;
        movie_links_div.appendChild(linkElement);
    }

    // Add event listeners to remove buttons
    document.querySelectorAll('.remove-link-btn').forEach((button) => {
        button.addEventListener('click', function () {
            let linkToRemove = button.getAttribute('data-link');
            remove_link(linkToRemove);
        });
    });

    const publicLinks = await fetchPublicLinks(imdb); // Fetch and display public links
}


    // Add/Remove Movie from Favorites
    document.getElementById('favorite-button').addEventListener('click', async () => {
        if (isFavorite) {
            links.innerHTML = "";
            user.favorites = user.favorites.filter((fav) => fav.imdbid !== imdb);
        } else {
            links.innerHTML = `<strong>Links:</strong>
                <div id="movie-links"></div>
                <input type="text" id="link-input" class="form-control" placeholder="Add a new link">
                <button id="add-link-button" class="btn btn-primary mt-2">Add Link</button>`;
            user.favorites.push(movie);
        }
        await updateUserFavorites(user.email, user.favorites);
        isFavorite = !isFavorite;
        document.getElementById("favorite-button").innerHTML = isFavorite
            ? "Remove from favorites"
            : "Add to favorites";
        window.location.reload();
    });

    document.getElementById("back-button").addEventListener("click", function () {
        const prevQuery = new URLSearchParams(window.location.search).get('prev');
        window.location.href = `index2.html?query=${prevQuery}`;
    });

    // Update user's favorites on the server
    async function updateUserFavorites(email, favorites) {
        
        try {
            await fetch('/user/update-user', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, favorites }),
            });
        } catch (err) {
            console.error('Failed to update favorites:', err);
        }
    }
});

document.getElementById('favorites-btn').addEventListener('click', ()=>{
    window.location.href = '/favorites'
})

