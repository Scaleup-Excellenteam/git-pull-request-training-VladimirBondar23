document.addEventListener("DOMContentLoaded", async function () {
    const container = document.getElementById("movies-container");

    try {
        const linksResponse = await fetch('/links/all');
        if (linksResponse.ok) {
            const links = await linksResponse.json(); // List of all links

            // Group links by movie_id and select the one with the highest click_count
            const groupedLinks = groupLinksByMovie(links);

            // Render the links dynamically
            RenderLinksCard(groupedLinks, container);
        } else {
            console.error('Failed to fetch links');
        }
    } catch (err) {
        console.error('Error fetching links:', err);
    }
});

async function RenderLinksCard(links, container) {
    for (const link of links) {
        let imdb = link.movie_id;

        // Fetch movie details
        const movie = await MoviesAPI.fetchMoviesDetails(imdb);

        // Create a list of links for the movie
        const cardHTML = `
            <div class="col-md-12 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">${movie.title} (${movie.year})</h5>
                        <ul class="list-group" id="links-list-${imdb}">
                            <!-- Links will be dynamically inserted here -->
                        </ul>
                    </div>
                </div>
            </div>
        `;

        // Append the card to the container
        container.insertAdjacentHTML('beforeend', cardHTML);

        // Dynamically render the link details for this movie
        renderLinksForMovie(link, `links-list-${imdb}`);
    }
}

function renderLinksForMovie(link, listId) {
    const listContainer = document.getElementById(listId);

    // Add each link dynamically
    const linkItem = document.createElement('li');
    linkItem.classList.add('list-group-item');

    linkItem.innerHTML = `
        <strong>${link.link_name}:</strong> ${link.link_description} -
        <a href="${link.link_url}" target="_blank" class="public-link">${link.link_url}</a>
        <p>Added by ${link.created_by}</p>
        <span class="badge bg-info">${link.click_count} clicks</span>
    `;

    // Add click event to increment click count when link is clicked
    const linkElement = linkItem.querySelector('a.public-link');
    linkElement.addEventListener('click', async (e) => {
        e.preventDefault(); // Prevent default action (opening the link)

        try {
            // Call the PUT method to increment the click count
            await incrementClickCount(link);

            // Open the link in a new tab
            window.open(link.link_url, '_blank');
        } catch (error) {
            console.error('Failed to increment click count:', error);
        }
    });

    listContainer.appendChild(linkItem);
}

async function incrementClickCount(link) {
    try {
        // Call the PUT method to increment the click count
        const response = await fetch(`/links/${link.movie_id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                link_name: link.link_name,
                link_description: link.link_description,
                link_url: link.link_url,
            }),
        });

        if (!response.ok) {
            throw new Error(`Failed to increment click count: ${response.statusText}`);
        }

        
    } catch (error) {
        console.error('Error incrementing click count:', error);
    }
}




document.getElementById('favorites-btn').addEventListener('click', () => {
    window.location.href = '/favorites';
});

function groupLinksByMovie(links) {
    const grouped = {};

    links.forEach(link => {
        const { movie_id, click_count } = link;

        if (!grouped[movie_id]) {
            grouped[movie_id] = link;
        } else if (click_count > grouped[movie_id].click_count) {
            grouped[movie_id] = link; // Update to the link with higher click_count
        }
    });

    return Object.values(grouped); // Return only the links with the highest click_count for each movie
}
