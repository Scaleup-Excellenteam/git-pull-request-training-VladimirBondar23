const API_KEY = '65afbc7f';
const BASE_URL = 'http://www.omdbapi.com/';

class Movie {
    constructor(id, title, year, plot, imdbid, poster, director, genre, actors, rating) {
        this.id = id;
        this.title = title;
        this.year = year;
        this.plot = plot;
        this.imdbid = imdbid;
        this.poster = poster;
        this.director = director;  
        this.genre = genre;        
        this.actors = actors;      
        this.rating = rating;      
        this.links = [];
    }}

    class MoviesAPI {
        static async fetchMovies(query) {
            const response = await fetch(`${BASE_URL}?apikey=${API_KEY}&s=${query}`);
            const data = await response.json();
            if (data.Response === "True") {
                let moviesListFound = data.Search;
                return moviesListFound.map(m => 
                    new Movie(m.imdbID, m.Title, m.Year, "", m.imdbID, m.Poster, "", "", "", "")
                );
            }
            return [];
        }
    
        static async fetchMoviesDetails(imdbid) {
            let response = await fetch(`${BASE_URL}?apikey=${API_KEY}&i=${imdbid}`);
            const data = await response.json();
            if (data.Response === "True") {
                return new Movie(
                    data.imdbID,
                    data.Title,
                    data.Year,
                    data.Plot,
                    data.imdbID,
                    data.Poster,
                    data.Director || "Unknown",  
                    data.Genre || "Unknown",
                    data.Actors || "Unknown",
                    data.imdbRating || "N/A"
                );
            }
            return null;
        }
    
        static RenderMoviesCard(movies, container) {
            container.innerHTML = ""; // Clear existing content
            movies.forEach(movie => {
                const card = `
                    <div class="col-md-3 mb-4">
                        <div class="card" style="width: 18rem;">
                            <img src="${movie.poster}" class="card-img-top" alt="${movie.title}">
                            <div class="card-body">
                                <h5 class="card-title">${movie.title}</h5>
                                <p class="card-text">${movie.year}</p>
                                <a href="details.html?imdbID=${movie.imdbid}&prev=${document.getElementById('search-txt').value}" class="btn btn-primary">Details</a>
                            </div>
                        </div>
                    </div>
                `;
                container.insertAdjacentHTML('beforeend', card);
            });
        }
        static RenderMoviesCard2(movies, container) {
            container.innerHTML = ""; // Clear existing content
            movies.forEach(movie => {
                const card = `
                    <div class="col-md-3 mb-4">
                        <div class="card" style="width: 18rem;">
                            <img src="${movie.poster}" class="card-img-top" alt="${movie.title}">
                            <div class="card-body">
                                <h5 class="card-title">${movie.title}</h5>
                                <p class="card-text">${movie.year}</p>
                                <a href="details.html?imdbID=${movie.imdbid}&prev=${' '}" class="btn btn-primary">Details</a>
                            </div>
                        </div>
                    </div>
                `;
                container.insertAdjacentHTML('beforeend', card);
            });
        }
    }

document.getElementById('logout-btn').addEventListener('click', ()=>{
    window.location.href = '/auth/login'
})
    