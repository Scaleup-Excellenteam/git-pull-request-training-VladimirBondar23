document.addEventListener("DOMContentLoaded", async function () {
    try {
        // Fetch current user details
        const response = await fetch('/user/current-user');
        if (response.ok) {
            const { username, email ,favorites } = await response.json();

            if (email === "vdecbel@gmail.com"){
                document.getElementById('header-title').innerText = `Admin's Favorites`;
            }
            else{

                document.getElementById('header-title').innerText = `${username}'s Favorites`;
            }
            // Update header title with username

            // Render user's favorite movies
            const movies = favorites;
            MoviesAPI.RenderMoviesCard2(movies, document.getElementById("movies-container"));
        } else {
            console.error('Failed to fetch current user');
            window.location.href = '/';
        }
    } catch (err) {
        console.error('Failed to fetch user:', err);
        window.location.href = '/';
    }
});

// Back button event listener
document.getElementById('back-btn').addEventListener('click', () => {
    window.location.href = '/index2';
});

// Logout button event listener
document.getElementById('logout-btn').addEventListener('click', () => {
    window.location.href = '/auth/login';
});
